# Admin Manual

This document describes administrative tasks in ZollPilot.

## Prerequisites

- You must have ADMIN or OWNER role
- Access admin area at `/admin`

## Managing Plans

### View Plans

1. Navigate to `/admin/plans`
2. See list of all plans with status (Active/Inactive)

### Create a Plan

1. Click "+ Create Plan"
2. Fill in:
   - **Code**: Uppercase identifier (e.g., `BASIC`, `PREMIUM`)
   - **Name**: Display name (e.g., "Basic Plan")
   - **Interval**: NONE, MONTHLY, YEARLY, or ONE_TIME
   - **Price (cents)**: Optional, for display only (no payment processing)
3. Click "Create Plan"

### Activate/Deactivate Plans

- Click "Activate" to make a plan available for assignment
- Click "Deactivate" to hide a plan (existing assignments remain)

## Managing Tenants

### View Tenants

1. Navigate to `/admin/tenants`
2. See list with: Name, Plan, Credits Balance, Created Date

### Assign Plan to Tenant

1. Click "Manage" on a tenant
2. Select a plan from dropdown
3. Click "Set Plan"

### Grant Credits to Tenant

1. Click "Manage" on a tenant
2. Enter amount (positive number)
3. Optionally add a note
4. Click "Grant Credits"

The balance updates immediately and a ledger entry is created.

### View Credit Ledger

1. Click "Manage" on a tenant
2. Scroll to "Credit Ledger" section
3. See last 50 transactions with:
   - Date
   - Delta (+/- amount)
   - Reason (e.g., ADMIN_GRANT)
   - Note

## Common Tasks

### Initial Setup

1. Register first user (becomes OWNER)
2. Go to `/admin/plans`
3. Create plans (FREE is seeded automatically)
4. Assign FREE plan to your tenant at `/admin/tenants`

### Granting Trial Credits

1. Go to `/admin/tenants`
2. Find the tenant
3. Click "Manage"
4. Grant credits with note "Trial credits"

### Troubleshooting Low Credits

1. Check ledger for consumption patterns
2. Look for unexpected negative deltas
3. Contact user if suspicious activity

## Credit Consumption

### PDF Export

When a user downloads a PDF from a submitted case:
- **1 credit is consumed** per download
- Ledger entry created with:
  - **Reason**: `PDF_EXPORT`
  - **Delta**: `-1`
  - **Metadata**: `{ case_id, version }`
  - **User**: The user who triggered the download

### Monitoring PDF Exports

1. Go to `/admin/tenants`
2. Click "Manage" on a tenant
3. Filter ledger by reason `PDF_EXPORT`
4. Review case_id in metadata to identify exported cases

### Credit Pricing Recommendations

| Action | Suggested Credits |
|--------|-------------------|
| PDF Export | 1 credit |
| Future: Priority Processing | 5 credits |
| Future: Extended Storage | 2 credits/month |

### Handling "Insufficient Credits"

When users report they cannot download PDFs:

1. Verify their balance at `/admin/tenants`
2. If legitimate, grant credits with note "Support: PDF access"
3. If suspicious (many exports), investigate case list

## API Reference

See `docs/API_CONTRACTS.md` for detailed endpoint documentation.

- `GET /admin/plans` - List plans
- `POST /admin/plans` - Create plan
- `PATCH /admin/plans/{id}` - Update plan
- `POST /admin/plans/{id}/activate` - Activate
- `POST /admin/plans/{id}/deactivate` - Deactivate
- `GET /admin/tenants` - List tenants
- `POST /admin/tenants/{id}/plan` - Assign plan
- `POST /admin/tenants/{id}/credits/grant` - Grant credits
- `GET /admin/tenants/{id}/credits/ledger` - View ledger

