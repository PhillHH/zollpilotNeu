# API Contracts

## Standard Response Shapes

### Success

```
{ "data": ... }
```

### Error

```
{
  "error": { "code": "STRING", "message": "STRING", "details": "OPTIONAL" },
  "requestId": "STRING"
}
```

## Headers

- `X-Request-Id`: returned by the API for every response.
- `X-Contract-Version`: required on every request (current: `1`).

Missing or invalid `X-Contract-Version` returns:

```
{
  "error": { "code": "CONTRACT_VERSION_INVALID", "message": "Contract version missing or invalid." },
  "requestId": "STRING"
}
```

## Error Codes

All error codes are centrally defined and consistently used across the API.

### Authentication & Authorization (4xx)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `AUTH_REQUIRED` | 401 | Authentication required (no session) |
| `INVALID_CREDENTIALS` | 401 | Email or password incorrect |
| `INVALID_SESSION` | 401 | Session token invalid or expired |
| `NO_MEMBERSHIP` | 401 | User has no tenant membership |
| `NO_TENANT` | 401 | User's tenant not found |
| `FORBIDDEN` | 403 | Insufficient permissions (RBAC) |
| `EMAIL_IN_USE` | 409 | Email already registered |

**Authorization Behavior:**

- **Tenant Isolation**: Users can only access resources belonging to their tenant
- **Cross-Tenant Access**: Returns `404 NOT_FOUND` (not `403`) to avoid leaking resource existence
- **Admin Endpoints**: All `/admin/*` endpoints require `SYSTEM_ADMIN` role
- **Security Logging**: All access violations are logged for audit

**Role Hierarchy:**

| Role | Level | Description |
|------|-------|-------------|
| `SYSTEM_ADMIN` | 5 | Full system access (ZollPilot internal) |
| `OWNER` | 4 | Tenant owner |
| `ADMIN` | 3 | Tenant administrator |
| `EDITOR` | 2 | Content editor (blog/FAQ) |
| `USER` | 1 | Standard user |

### Not Found (404)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `NOT_FOUND` | 404 | Generic resource not found |
| `CASE_NOT_FOUND` | 404 | Case not found or not accessible (tenant-scoped) |
| `PROCEDURE_NOT_FOUND` | 404 | Procedure not found |
| `SNAPSHOT_NOT_FOUND` | 404 | Snapshot not found |
| `PLAN_NOT_FOUND` | 404 | Plan not found |
| `TENANT_NOT_FOUND` | 404 | Tenant not found |

### Validation & Bad Request (400)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `VALIDATION_ERROR` | 400 | Request validation failed (includes details) |
| `CONTRACT_VERSION_INVALID` | 400 | Missing or invalid X-Contract-Version header |
| `NO_PROCEDURE_BOUND` | 400 | Case has no procedure bound |

### Conflict (409)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `CASE_INVALID` | 409 | Case validation failed (submit gate) |
| `CASE_NOT_EDITABLE` | 409 | Case is not in DRAFT status (fields locked) |
| `CASE_NOT_SUBMITTED` | 409 | Case must be SUBMITTED for this action |
| `CASE_ARCHIVED` | 409 | Archived cases cannot be modified |
| `NO_SNAPSHOT` | 409 | No snapshot exists |

### Payment & Credits (402)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `INSUFFICIENT_CREDITS` | 402 | Not enough credits (balance < 1) |

### Payload (413)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `PAYLOAD_TOO_LARGE` | 413 | Request body exceeds size limit (16KB for fields) |

### Rate Limiting (429)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `RATE_LIMITED` | 429 | Too many requests (see Retry-After header) |

Rate limiting returns additional headers:
- `Retry-After`: Seconds until next request allowed
- `X-RateLimit-Limit`: Maximum requests per window
- `X-RateLimit-Remaining`: Remaining requests in window
- `X-RateLimit-Reset`: Unix timestamp when window resets

### Server Error (500)

| Code | HTTP Status | Description |
|------|-------------|-------------|
| `INTERNAL_SERVER_ERROR` | 500 | Unexpected server error |

## Endpoints

### Auth

- `POST /auth/register`
- `POST /auth/login`
- `POST /auth/logout`
- `GET /auth/me`

### Cases

All case endpoints require authentication and are tenant-scoped.

#### `POST /cases`
Create a new case.

**Request Body:**
```json
{ "title": "optional string" }
```

**Response (201):**
```json
{ "data": { "id": "uuid", "title": "string", "status": "DRAFT", "created_at": "datetime", "updated_at": "datetime" } }
```

#### `GET /cases`
List cases for the current tenant.

**Query Parameters:**
- `status`: Filter by status. Values: `active` (default, DRAFT|SUBMITTED), `archived`, `all`

**Response (200):**
```json
{ "data": [{ "id": "uuid", "title": "string", "status": "string", "created_at": "datetime", "updated_at": "datetime" }] }
```

#### `GET /cases/{id}`
Get case details including fields.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "title": "string",
    "status": "string",
    "created_at": "datetime",
    "updated_at": "datetime",
    "archived_at": "datetime|null",
    "fields": [{ "key": "string", "value": "any", "updated_at": "datetime" }]
  }
}
```

#### `PATCH /cases/{id}`
Update case properties.

**Request Body:**
```json
{ "title": "optional string" }
```

**Response (200):** CaseSummary

#### `POST /cases/{id}/archive`
Archive a case. Sets status to ARCHIVED and archived_at timestamp.
Idempotent: calling multiple times is safe.

**Response (200):** CaseSummary

### Case Fields (tag: case-fields)

Generic key-value storage for case data. Wizard-ready design.

#### `GET /cases/{id}/fields`
Get all fields for a case.

**Response (200):**
```json
{ "data": [{ "key": "string", "value": "any", "updated_at": "datetime" }] }
```

#### `PUT /cases/{id}/fields/{key}`
Upsert a field value.

**Path Parameters:**
- `key`: Field key (pattern: `[a-z0-9_.-]{1,64}`)

**Request Body:**
```json
{ "value": "any JSON value (max 16KB)" }
```

**Response (200):**
```json
{ "data": { "key": "string", "value": "any", "updated_at": "datetime" } }
```

**Errors:**
- 400 `VALIDATION_ERROR`: Invalid key pattern
- 413 `PAYLOAD_TOO_LARGE`: Value exceeds 16KB

### Procedures (tag: procedures)

Configuration-driven procedure definitions. See `docs/PROCEDURES.md` for details.

#### `GET /procedures`
List all active procedures.

**Response (200):**
```json
{ "data": [{ "code": "string", "name": "string", "version": "string" }] }
```

#### `GET /procedures/{code}`
Get full procedure definition with steps and fields.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "code": "string",
    "name": "string",
    "version": "string",
    "is_active": "bool",
    "steps": [{
      "step_key": "string",
      "title": "string",
      "order": "int",
      "fields": [{
        "field_key": "string",
        "field_type": "TEXT|NUMBER|SELECT|COUNTRY|CURRENCY|BOOLEAN",
        "required": "bool",
        "config": "object|null",
        "order": "int"
      }]
    }]
  }
}
```

#### `POST /cases/{id}/procedure`
Bind a procedure to a case. Idempotent.

**Request Body:**
```json
{ "procedure_code": "string" }
```

**Response (200):**
```json
{ "data": { "case_id": "uuid", "procedure_code": "string", "procedure_version": "string" } }
```

**Errors:**
- 400 `PROCEDURE_NOT_FOUND`: Procedure code not found

#### `POST /cases/{id}/validate`
Validate case fields against bound procedure.

**Response (200):**
```json
{
  "data": {
    "valid": "bool",
    "errors": [{ "step_key": "string", "field_key": "string", "message": "string" }] | null
  }
}
```

**Errors:**
- 400 `NO_PROCEDURE_BOUND`: Case has no procedure bound

### Case Lifecycle (tag: case-lifecycle)

Case submission and snapshot management.

#### `POST /cases/{id}/submit`
Submit a case. Validates and creates an immutable snapshot.

**Response (200):**
```json
{
  "data": {
    "status": "SUBMITTED",
    "version": 1,
    "snapshot_id": "uuid"
  }
}
```

**Errors:**
- 400 `NO_PROCEDURE_BOUND`: Case has no procedure bound
- 409 `CASE_INVALID`: Validation failed (includes error details)
- 409 `CASE_ARCHIVED`: Cannot submit archived case

Idempotent: calling on already-submitted case returns existing snapshot info.

#### `GET /cases/{id}/snapshots`
List all snapshots for a case.

**Response (200):**
```json
{
  "data": [
    { "id": "uuid", "version": 1, "created_at": "datetime" }
  ]
}
```

#### `GET /cases/{id}/snapshots/{version}`
Get snapshot detail by version.

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "case_id": "uuid",
    "version": 1,
    "procedure_code": "string",
    "procedure_version": "string",
    "fields_json": { "key": "value" },
    "validation_json": { "valid": true, "errors": [] },
    "created_at": "datetime"
  }
}
```

**Errors:**
- 404 `SNAPSHOT_NOT_FOUND`: Snapshot with given version not found

#### `GET /cases/{id}/summary`
Get structured, human-readable summary for a case.

Returns formatted data organized into sections with proper formatting (country names, currency symbols, etc.).

**Response (200):**
```json
{
  "data": {
    "procedure": {
      "code": "string",
      "version": "string",
      "name": "string"
    },
    "sections": [
      {
        "title": "string",
        "items": [
          { "label": "string", "value": "string" }
        ]
      }
    ]
  }
}
```

**Example Response (IZA):**
```json
{
  "data": {
    "procedure": { "code": "IZA", "version": "v1", "name": "Import Zollanmeldung" },
    "sections": [
      {
        "title": "Paket",
        "items": [
          { "label": "Inhalt", "value": "Electronics - Smartphone" },
          { "label": "Warenwert", "value": "150,00 €" },
          { "label": "Herkunftsland", "value": "China" }
        ]
      },
      {
        "title": "Empfänger",
        "items": [
          { "label": "Name", "value": "Max Mustermann" },
          { "label": "Land", "value": "Deutschland" }
        ]
      }
    ]
  }
}
```

**Errors:**
- 400 `NO_PROCEDURE_BOUND`: Case has no procedure bound

### PDF Export (tag: pdf)

Export submitted cases as PDF documents. Requires credits.

#### `POST /cases/{id}/pdf`
Export a case as PDF. Consumes 1 credit.

**Preconditions:**
- Case status must be `SUBMITTED`
- At least one snapshot must exist
- Tenant must have at least 1 credit

**Response (200):**
- Content-Type: `application/pdf`
- Content-Disposition: `attachment; filename="ZollPilot_IZA_{case_id_short}_v{version}.pdf"`
- X-Credits-Consumed: `1`

Returns the PDF file as a binary stream.

**Errors:**
- 404 `CASE_NOT_FOUND`: Case not found or not accessible
- 409 `CASE_NOT_SUBMITTED`: Case is not in SUBMITTED status
- 409 `NO_SNAPSHOT`: No snapshot exists for the case
- 402 `INSUFFICIENT_CREDITS`: Tenant has no credits

**Credit Consumption:**
- On success, 1 credit is deducted from the tenant's balance
- A ledger entry is created with:
  - `delta`: -1
  - `reason`: "PDF_EXPORT"
  - `metadata_json`: `{ "case_id": "uuid", "version": int }`
  - `created_by_user_id`: User who triggered the export

**PDF Contents:**
- DIN A4 format
- Header: ZollPilot logo, generation date, request ID
- Case info: Case ID, version, procedure
- Sections: All fields from CaseSummary, formatted values
- Footer: Legal disclaimer, page numbers

**Example Filename:**
```
ZollPilot_IZA_abc12345_v1.pdf
```

### Billing (tag: billing)

User-facing billing information.

#### `GET /billing/me`
Get billing information for the current user's tenant.

**Response (200):**
```json
{
  "data": {
    "tenant": { "id": "uuid", "name": "string" },
    "plan": { "code": "string", "name": "string", "interval": "string", "price_cents": "int|null", "currency": "string" } | null,
    "credits": { "balance": "int" }
  }
}
```

#### `GET /billing/history`
Get credit transaction history for the current user's tenant.

**Query Parameters:**
- `limit`: Max entries to return (default: 50, max: 100)

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "delta": "int (+/- credits)",
      "reason": "string (ADMIN_GRANT | PDF_EXPORT | INITIAL_GRANT | PURCHASE | REFUND)",
      "case_title": "string|null (title of related case if applicable)",
      "created_at": "datetime"
    }
  ]
}
```

**Reason Codes:**
| Code | Description |
|------|-------------|
| `ADMIN_GRANT` | Credits granted by admin |
| `PDF_EXPORT` | Credits consumed for PDF export |
| `INITIAL_GRANT` | Initial credits on signup |
| `PURCHASE` | Credits purchased |
| `AUSFUELLHILFE` | Credits used for Ausfüllhilfe |
| `REFUND` | Credits refunded |

### Checkout (tag: checkout)

Stripe Checkout integration for purchasing credits.

#### `GET /billing/products`
List available products for purchase.

**Response (200):**
```json
{
  "data": [
    {
      "id": "string (product_id)",
      "name": "string",
      "description": "string",
      "price_cents": "int",
      "credits": "int",
      "type": "CREDITS|IZA_PASS"
    }
  ]
}
```

#### `POST /billing/checkout/session`
Create a Stripe Checkout session.

**Request Body:**
```json
{ "product_id": "string" }
```

**Response (200):**
```json
{
  "data": {
    "checkout_url": "string (Stripe Checkout URL)",
    "session_id": "string (Stripe session ID)",
    "product_id": "string",
    "amount_cents": "int",
    "currency": "string"
  }
}
```

**Errors:**
- 422 `VALIDATION_ERROR`: Invalid product_id

#### `POST /billing/webhook`
Handle Stripe webhook events. No authentication required.

**Request Body:** Stripe webhook payload (JSON)

**Headers:**
- `Stripe-Signature`: Webhook signature (verified in production)

**Response (200):**
```json
{
  "received": "bool",
  "processed": "bool",
  "reason": "string (optional, why not processed)"
}
```

#### `GET /billing/purchases`
List purchases for the current tenant.

**Query Parameters:**
- `limit`: Max entries to return (default: 20, max: 100)

**Response (200):**
```json
{
  "data": [
    {
      "id": "uuid",
      "type": "CREDITS|IZA_PASS",
      "status": "PENDING|PAID|FAILED|REFUNDED",
      "amount_cents": "int",
      "currency": "string",
      "credits_amount": "int|null",
      "product_name": "string|null",
      "created_at": "datetime",
      "paid_at": "datetime|null"
    }
  ]
}
```

#### `GET /billing/purchases/{id}`
Get a single purchase (receipt).

**Response (200):**
```json
{
  "data": {
    "id": "uuid",
    "type": "CREDITS|IZA_PASS",
    "status": "PENDING|PAID|FAILED|REFUNDED",
    "amount_cents": "int",
    "currency": "string",
    "credits_amount": "int|null",
    "product_name": "string|null",
    "created_at": "datetime",
    "paid_at": "datetime|null"
  }
}
```

**Errors:**
- 404 `NOT_FOUND`: Purchase not found or not accessible

### Profile (tag: profile)

User profile for storing reusable data (form pre-filling).

#### `GET /profile`
Get the current user's profile.

**Response (200):**
```json
{
  "data": {
    "user_id": "uuid",
    "email": "string",
    "name": "string|null",
    "address": "string|null",
    "default_sender_name": "string|null",
    "default_sender_country": "string|null (ISO 2-letter code)",
    "default_recipient_name": "string|null",
    "default_recipient_country": "string|null (ISO 2-letter code)",
    "preferred_countries": "string[]|null",
    "preferred_currencies": "string[]|null",
    "updated_at": "datetime|null"
  }
}
```

#### `PUT /profile`
Update the current user's profile. Creates profile if it doesn't exist.

**Request Body:**
```json
{
  "name": "string (optional, max 200)",
  "address": "string (optional, max 500)",
  "default_sender_name": "string (optional, max 200)",
  "default_sender_country": "string (optional, ISO 2-letter code)",
  "default_recipient_name": "string (optional, max 200)",
  "default_recipient_country": "string (optional, ISO 2-letter code)",
  "preferred_countries": "string[] (optional)",
  "preferred_currencies": "string[] (optional)"
}
```

**Response (200):** Same as GET /profile

### Admin (tag: admin)

Admin endpoints require ADMIN or OWNER role.

#### Plans

##### `GET /admin/plans`
List all plans.

**Response (200):**
```json
{ "data": [{ "id": "uuid", "code": "string", "name": "string", "is_active": "bool", "interval": "string", "price_cents": "int|null", "currency": "string", "created_at": "datetime", "updated_at": "datetime" }] }
```

##### `POST /admin/plans`
Create a new plan.

**Request Body:**
```json
{ "code": "string (pattern: [A-Z0-9_]{2,32})", "name": "string", "interval": "ONE_TIME|YEARLY|MONTHLY|NONE", "price_cents": "int (optional)", "currency": "string (default EUR)" }
```

**Response (201):** Plan object

##### `PATCH /admin/plans/{id}`
Update a plan.

**Request Body:**
```json
{ "name": "string (optional)", "price_cents": "int (optional)", "currency": "string (optional)", "interval": "string (optional)" }
```

**Response (200):** Plan object

##### `POST /admin/plans/{id}/activate`
Activate a plan.

**Response (200):** Plan object

##### `POST /admin/plans/{id}/deactivate`
Deactivate a plan.

**Response (200):** Plan object

#### Tenants

##### `GET /admin/tenants`
List all tenants with plan and credit info.

**Response (200):**
```json
{ "data": [{ "id": "uuid", "name": "string", "plan_code": "string|null", "credits_balance": "int", "created_at": "datetime" }] }
```

##### `POST /admin/tenants/{id}/plan`
Assign a plan to a tenant.

**Request Body:**
```json
{ "plan_code": "string" }
```

**Response (200):** TenantSummary

##### `POST /admin/tenants/{id}/credits/grant`
Grant credits to a tenant. Creates ledger entry.

**Request Body:**
```json
{ "amount": "int (>0)", "note": "string (optional)" }
```

**Response (200):**
```json
{ "data": { "balance": "int" } }
```

##### `GET /admin/tenants/{id}/credits/ledger`
Get credit ledger entries for a tenant.

**Query Parameters:**
- `limit`: Max entries to return (default: 50, max: 100)

**Response (200):**
```json
{ "data": [{ "id": "uuid", "delta": "int", "reason": "string", "metadata_json": "any|null", "created_by_user_id": "uuid|null", "created_at": "datetime" }] }
```

#### Admin Content (tag: admin-content)

Admin endpoints for managing blog and FAQ content. Requires EDITOR role or higher.

##### `GET /admin/content/blog`
List all blog posts (includes drafts).

**Query Parameters:**
- `status`: Filter by status (DRAFT, PUBLISHED)

**Response (200):**
```json
{ "data": [{ "id": "uuid", "title": "string", "slug": "string", "excerpt": "string", "status": "DRAFT|PUBLISHED", "published_at": "datetime|null", "created_at": "datetime", "updated_at": "datetime" }], "total": "int" }
```

##### `GET /admin/content/blog/{id}`
Get a single blog post by ID.

**Response (200):**
```json
{ "data": { "id": "uuid", "title": "string", "slug": "string", "excerpt": "string", "content": "string", "status": "DRAFT|PUBLISHED", "published_at": "datetime|null", "created_at": "datetime", "updated_at": "datetime", "meta_title": "string|null", "meta_description": "string|null", "created_by_user_id": "uuid|null", "updated_by_user_id": "uuid|null" } }
```

##### `POST /admin/content/blog`
Create a new blog post.

**Request Body:**
```json
{ "title": "string", "slug": "string (unique)", "excerpt": "string", "content": "string", "status": "DRAFT|PUBLISHED (default: DRAFT)", "meta_title": "string (optional)", "meta_description": "string (optional)" }
```

**Response (201):** BlogPost object

**Errors:**
- 409 `SLUG_EXISTS`: Slug already in use

##### `PUT /admin/content/blog/{id}`
Update a blog post.

**Request Body:**
```json
{ "title": "string (optional)", "slug": "string (optional)", "excerpt": "string (optional)", "content": "string (optional)", "status": "DRAFT|PUBLISHED (optional)", "meta_title": "string (optional)", "meta_description": "string (optional)" }
```

**Response (200):** BlogPost object

##### `DELETE /admin/content/blog/{id}`
Delete a blog post.

**Response (204):** No content

##### `GET /admin/content/faq`
List all FAQ entries (includes drafts).

**Query Parameters:**
- `status`: Filter by status (DRAFT, PUBLISHED)
- `category`: Filter by category

**Response (200):**
```json
{ "data": [{ "id": "uuid", "question": "string", "category": "string", "order_index": "int", "status": "DRAFT|PUBLISHED", "published_at": "datetime|null", "created_at": "datetime", "updated_at": "datetime" }], "total": "int" }
```

##### `GET /admin/content/faq/{id}`
Get a single FAQ entry by ID.

**Response (200):**
```json
{ "data": { "id": "uuid", "question": "string", "answer": "string", "category": "string", "order_index": "int", "status": "DRAFT|PUBLISHED", "published_at": "datetime|null", "created_at": "datetime", "updated_at": "datetime", "related_blog_post_id": "uuid|null", "created_by_user_id": "uuid|null", "updated_by_user_id": "uuid|null" } }
```

##### `POST /admin/content/faq`
Create a new FAQ entry.

**Request Body:**
```json
{ "question": "string", "answer": "string", "category": "string (default: Allgemein)", "order_index": "int (default: 0)", "status": "DRAFT|PUBLISHED (default: DRAFT)", "related_blog_post_id": "uuid (optional)" }
```

**Response (201):** FaqEntry object

##### `PUT /admin/content/faq/{id}`
Update a FAQ entry.

**Request Body:**
```json
{ "question": "string (optional)", "answer": "string (optional)", "category": "string (optional)", "order_index": "int (optional)", "status": "DRAFT|PUBLISHED (optional)", "related_blog_post_id": "uuid (optional)" }
```

**Response (200):** FaqEntry object

##### `DELETE /admin/content/faq/{id}`
Delete a FAQ entry.

**Response (204):** No content

##### `GET /admin/content/categories`
List all unique FAQ categories.

**Response (200):**
```json
{ "data": ["string"] }
```

### Prefill (tag: prefill)

Invoice/receipt upload and field extraction for faster data entry.

#### `POST /prefill/upload`
Upload an invoice or receipt and extract field suggestions.

**Request:**
- Content-Type: `multipart/form-data`
- `file`: PDF, JPG, or PNG (max 10 MB)

**Response (200):**
```json
{
  "data": {
    "suggestions": [
      {
        "field_key": "string (e.g., value_amount)",
        "value": "any",
        "confidence": "float (0.0 - 1.0)",
        "source": "string (e.g., regex_total)",
        "display_label": "string (German label)"
      }
    ],
    "items": [
      {
        "name": "string",
        "price": "float|null",
        "currency": "string|null",
        "confidence": "float"
      }
    ],
    "raw_text_preview": "string|null (first 500 chars, debug only)",
    "extraction_method": "string (pdf_text|image_unsupported|none)",
    "warnings": ["string"]
  }
}
```

**Errors:**
- 400 `INVALID_FILE_TYPE`: Unsupported file format
- 400 `FILE_TOO_LARGE`: File exceeds 10 MB
- 400 `EMPTY_FILE`: Uploaded file is empty

**Privacy:**
- Files are processed in memory only
- No permanent storage
- No external services
- No logging of file contents

#### `GET /prefill/info`
Get information about the prefill feature.

**Response (200):**
```json
{
  "data": {
    "supported_formats": ["PDF", "JPG", "PNG"],
    "max_file_size_mb": 10,
    "features": ["string"],
    "limitations": ["string"],
    "privacy": {
      "storage": "string",
      "external_services": "string",
      "training": "string",
      "logging": "string"
    }
  }
}
```




